import React from "react"

const Services = () => {
    return (
        <div className="service" style={{backgroundImage: `url('https://thepinkplumber.com/wp-content/uploads/2018/07/The-Pink-Plumber_Finding-the-Best-Plumbers-in-Your-Area_IMAGE-1.jpeg')`}}>
        <h1 className="HomeStyle title">Services</h1>
        </div>
    )
}
export default Services