import React from "react"



const About = () => {
    return (
        
            <div className="bout" style={{backgroundImage: `url('https://rightpricetiles.ie/wp-content/uploads/2017/06/Victoria-Metro-Wall-Tiles-Gloss-Cream-20-x-10cm-Pack-of-50-d1.jpg')`}} >
                <div className="words">
                <h1 className="HomeStyle " >About</h1>
                    <p> If you want the best you gotta pay for the best, thats why here at top dollar plumbing we dont take no shit or deal with it either, for long, should i say. Super fast work, for that super bad smell. We cater to all needs except straight sewer work, thats for the city. Here at Top Dollar Plumbing, we dont love it but hey somebody gots to deal with this shit.</p>
                </div>
            </div>
            
        
        
    )
}
export default About