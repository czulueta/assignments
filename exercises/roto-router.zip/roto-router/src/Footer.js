import React from "react"

const Footer = () => {
    return (
        <footer className="foot"></footer>
    )
}
export default Footer